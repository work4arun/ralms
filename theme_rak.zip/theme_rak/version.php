<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Theme RAK - Version file.
 *
 * @package   theme_rak
 * @copyright 2024 RAK Theme
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'theme_rak';        // Full name of the plugin (used for diagnostics).
$plugin->version   = 2024120100;         // The current plugin version (Date: YYYYMMDDXX).
$plugin->requires  = 2024042200;         // Requires Moodle 4.4+ (use 2024100700 for 4.5).
$plugin->maturity  = MATURITY_STABLE;    // This version's maturity level.
$plugin->release   = '1.0.0';           // Human-readable version name.

$plugin->dependencies = [
    'theme_boost' => 2024042200,
];
